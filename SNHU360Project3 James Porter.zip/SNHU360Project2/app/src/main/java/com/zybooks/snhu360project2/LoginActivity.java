package com.zybooks.snhu360project2;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DownloadManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    private Button buttonLogin;
    private TextView usernameText;
    private TextView passwordText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        buttonLogin = findViewById(R.id.loginButton);
        usernameText = findViewById(R.id.username);
        passwordText = findViewById(R.id.password);

        setContentView(R.layout.activity_login);
    }

    public void loginButtonClicked(View view){
        /*
        Check username and password against the database here
        If the username and password are correct login
        Else prompt error
        */
        setContentView(R.layout.activity_calendar);

    }

    public void newUserButtonClicked(View view){
        //Sends the user to the new user screen to register their account
        setContentView(R.layout.activity_new_user);
    }
}