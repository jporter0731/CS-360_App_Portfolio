package com.zybooks.snhu360project2;

import java.text.ParseException;
import java.time.LocalTime;
import java.util.Date;

public class Event {
    private String eventTitle;
    private int eventMonth;
    private int eventDay;
    private int eventYear;
    private LocalTime eventTime;

    public Event(String mTitle, int mMonth, int mDay, int mYear, String mTime){
        setEventTitle(mTitle);
        setEventMonth(mMonth);
        setEventDay(mDay);
        setEventYear(mYear);
        setEventTitle(mTime);
    }

    public String getEventTitle(){
        return eventTitle;
    }

    public void setEventTitle(String mTitle){
        if (mTitle.length() <= 50){
            eventTitle = mTitle;
        }
        else {
            //String too long error here
        }
    }

    public int getEventMonth(){
        return eventMonth;
    }

    public void setEventMonth(int mMonth){
        if (mMonth <= 0){
            //Not a valid month if number is less than zero
        }
        else if (mMonth <= 12){
            eventMonth = mMonth;
        }
        else{
            //Not a valid month if number is greater than 12
        }
    }

    public int getEventDay(){
        return eventDay;
    }

    public void setEventDay(int mDay){
        //Make sure the day is not less than zero
        if (mDay <= 0){
            //Not a valid day if less than zero
        }
        //Check to make sure the date is not too high
        else{
            switch (eventMonth){
                //Checks months that have 31 days
                case 1: case 3: case 5: case 7: case 8: case 10: case 12:
                    if (mDay <= 31){
                        eventDay = mDay;
                    }
                    else{
                        //Invalid date error here
                    }
                //Checks February case
                case 2:
                    if (mDay <= 28){
                        eventDay = mDay;
                    }
                    else{
                        //Invalid date error here
                    }
                case 4: case 6: case 9: case 11:
                    if (mDay <= 30){
                        eventDay = mDay;
                    }
                    else{
                        //Invalid date error here
                    }
                default:
                    //Invalid month selected
            }
        }
    }

    public int getEventYear(){
        return eventYear;
    }

    public void setEventYear(int mYear){
        //Get details of the current year
        Date dt = new Date();
        int currentYear = dt.getYear();
        //Make sure the event is not for the past year
        if (mYear >= currentYear) {
            eventYear = mYear;
        }
        else{
            //Not a valid year if year is in the past
        }
    }

    public LocalTime getEventTime(){
        return eventTime;
    }

    public void setEventTime (String mTime){
        try{
            eventTime = LocalTime.parse(mTime);
        }
        catch (RuntimeException e){
            //Invalid time entered exception here
        }
    }
}
