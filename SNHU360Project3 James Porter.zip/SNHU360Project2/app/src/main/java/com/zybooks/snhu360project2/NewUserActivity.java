package com.zybooks.snhu360project2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class NewUserActivity extends AppCompatActivity {

    Button mNewUserButton;
    TextView mUsername;
    TextView mPassword;
    TextView mPasswordReenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Get variables to to create the new user
        mUsername = findViewById(R.id.newUsername);
        mPassword = findViewById(R.id.newPassword);
        mPasswordReenter = findViewById(R.id.newPasswordReenter);
        mNewUserButton = findViewById(R.id.newUserButton);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_user);
    }

    public void createNewUser(View view){
         if (mPassword.equals(mPasswordReenter)){
             Log.d("Passwords", "Passwords do match");
             Toast.makeText(getApplicationContext(),"New account created", Toast.LENGTH_SHORT).show();
             //Create the new user and add them to the database of users
             setContentView(R.layout.activity_login);
         }
         else{
             Log.d("Passwords", "Passwords don't match");
             Toast.makeText(getApplicationContext(),"Passwords do not match", Toast.LENGTH_SHORT).show();
         }
    }
}