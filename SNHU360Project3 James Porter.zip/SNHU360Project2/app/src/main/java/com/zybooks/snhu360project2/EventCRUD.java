package com.zybooks.snhu360project2;

public class EventCRUD {
    //Creates a new event and adds it to the database
    public void createEvent(String mTitle, int mMonth, int mDay, int mYear, String mTime){
        Event newEvent = new Event(mTitle, mMonth, mDay, mYear, mTime);
        //Add event to the database here
    }

    //Finds events in the database based on the title
    public Event readByTitle(String mTitle){
        //Get event from database
        Event getEvent = new Event(mTitle, 1, 1, 1, "12:00");

        return getEvent;
    }

    //Finds events in the database based on the date provided
    public Event readByDate(int mMonth, int mDate, int mYear){
        //Get event from database
        Event getEvent = new Event("Title here", mMonth, mDate, mYear, "12:00");

        return getEvent;
    }

    //Updates an event title given the title to search for
    public void updateEventTitle(String mSearchTitle, String mNewTitle){
        //Get event from database
        Event getEvent = readByTitle(mSearchTitle);
        //Set new title
        getEvent.setEventTitle(mNewTitle);
    }

    //Updates the event date given the title to search for
    public void updateEventDate(String mSearchTitle, int mNewMonth, int mNewDay, int mNewYear){
        //Get event from database
        Event getEvent = readByTitle(mSearchTitle);
        //Update the date of the event
        getEvent.setEventMonth(mNewMonth);
        getEvent.setEventDay(mNewDay);
        getEvent.setEventYear(mNewYear);
    }

    //Updates the event time given the title to search for
    public void updateEventTime(String mSearchTitle, String mNewTime){
        //Get event from database
        Event getEvent = readByTitle(mSearchTitle);
        //Update the event time
        getEvent.setEventTime(mNewTime);
    }

    //Delete an event by searching for the title
    public void deleteEvent(String mSearchTitle){
        //Get event from database
        Event getEvent = readByTitle(mSearchTitle);
        //Delete the event from the database
    }
}
